package com.example.common.di;

public interface CommonApplication {
    CommonComponent componen();
}
