package com.example.common.di.modules;

import javax.inject.Qualifier;

@Qualifier
public @interface ServerUrl {
}
